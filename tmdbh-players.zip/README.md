# tmdbh.players

Current Matrix Add-on Players for TheMovieDb-Helper (updated as of July 31 2022)

Enter URL into TheMovieDb-Helper settings for players: https://bit.ly/gplayers

G-Man