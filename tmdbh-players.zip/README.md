# tmdbh.players

Current Matrix Add-on Players for TheMovieDb-Helper

Enter URL into TheMovieDb-Helper settings for players: https://bit.ly/gplayers

G-Man